﻿Imports System.IO
Module ConnectionString
    Public ReadOnly cs As String = "Data source=Raj-PC\SQLExpress;Initial Catalog=CRUD_DB;Integrated Security=True;"
End Module
